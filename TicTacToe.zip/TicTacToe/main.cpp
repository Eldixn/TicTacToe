#include <iostream>
#include <vector>

using namespace std;

class TicTacToe {
public:
    /* Constructor */
    TicTacToe() {
        /* Initialize defaults here */
        currentPlayer = 'X'; // Player X starts
    }

    /* This is your game board */
    vector<vector<char>> gameBoard {
            {'1', '2', '3'},
            {'4', '5', '6'},
            {'7', '8', '9'}
    };

    /* This prints your game board */
    void printGameBoard() {
        for (int i = 0; i < gameBoard.size(); i++) {
            for (int j = 0; j < gameBoard[i].size(); j++) {
                cout << gameBoard[i][j] << " ";
            }
            cout << endl;
        }
    }

    /* This method modifies the game board */
    void modifyGameBoard(int position) {
        // Convert position to indices
        int row = (position - 1) / 3;
        int col = (position - 1) % 3;

        // Check if the position is valid and the cell is not already taken
        if (position >= 1 && position <= 9 && gameBoard[row][col] != 'X' && gameBoard[row][col] != 'O') {
            gameBoard[row][col] = currentPlayer;
        } else {
            cout << "Invalid move. Please try again." << endl;
        }
    }

    void switchPlayer() {
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }

    bool checkWin() {
        // Check rows, columns, and diagonals for a win
        for (int i = 0; i < 3; ++i) {
            if (gameBoard[i][0] == gameBoard[i][1] && gameBoard[i][1] == gameBoard[i][2]) return true; // Check rows
            if (gameBoard[0][i] == gameBoard[1][i] && gameBoard[1][i] == gameBoard[2][i]) return true; // Check columns
        }
        if (gameBoard[0][0] == gameBoard[1][1] && gameBoard[1][1] == gameBoard[2][2]) return true; // Check diagonal
        if (gameBoard[0][2] == gameBoard[1][1] && gameBoard[1][1] == gameBoard[2][0]) return true; // Check reverse diagonal

        return false;
    }

    bool isBoardFull() {
        // Check if the board is full (indicating a tie)
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (gameBoard[i][j] != 'X' && gameBoard[i][j] != 'O') {
                    return false; // There is an empty spot
                }
            }
        }
        return true; // Board is full
    }

    void playGame() {
        int position;

        do {
            printGameBoard();
            cout << "Player " << currentPlayer << " Enter Position: ";
            cin >> position;

            modifyGameBoard(position);

            if (checkWin()) {
                printGameBoard();
                cout << "Player " << currentPlayer << " wins!" << endl;
                break;
            }

            if (isBoardFull()) {
                printGameBoard();
                cout << "It's a tie!" << endl;
                break;
            }

            switchPlayer();
        } while (true);
    }

private:
    char currentPlayer; // 'X' or 'O'
};

int main() {
    TicTacToe game;
    game.playGame();

    return 0;
}
